import numpy as np
import random

def percent_visited(steps, visited,states):
    for _ in range(steps):
        current_state = random.randint(0, states-1)
        visited[current_state] = True
    return sum(visited)/float(states)


def trial_nums_calculation(percent):
    # 384 states * 4 action possible
    states = 384*4
    coverage = 0
    trial_runs = 0
    for i in range(0,10):
        visited = np.zeros(states, dtype=bool)
        while True:
            # on this work deadline is chosen on distance * 5. distance is minimum 5 steps away
            # The grid size (8,6) from top left to bottom down 14 steps
            n_steps = random.choice([s*5 for s in range(5,14)]) # steps in one episodes
            coverage = percent_visited(n_steps,visited, states)
            trial_runs += 1
            if coverage >=percent:
                break
        #print(coverage)
    print("minimum trial numbers needed for {0:.2f}% states to be visited: ".format(percent*100, trial_runs/10))
    return  trial_runs

trial_nums_calculation(0.8)
trial_nums_calculation(0.99)
trial_nums_calculation(1.0)
